# General Information {#general}

- @subpage directory_structure
- @subpage event
- @subpage logical_volumes
- @subpage vpp_integration
