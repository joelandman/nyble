static const char SNAPSHOT[] = "180608";
