..  SPDX-License-Identifier: BSD-3-Clause
    Copyright(c) 2010-2015 Intel Corporation.

Description of Release
======================

This document contains the release notes for Data Plane Development Kit (DPDK)
release version |release| and previous releases.

It lists new features, fixed bugs, API and ABI changes and known issues.

For instructions on compiling and running the release, see the :ref:`DPDK Getting Started Guide <linux_gsg>`.
