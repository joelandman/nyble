..  SPDX-License-Identifier: BSD-3-Clause
    Copyright 2018 NXP

Rawdev Drivers
==============

The following are a list of raw device PMDs, which can be used from an
application through rawdev API.

.. toctree::
    :maxdepth: 2
    :numbered:

    dpaa2_cmdif
    dpaa2_qdma
    ifpga_rawdev
