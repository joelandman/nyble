..  SPDX-License-Identifier: BSD-3-Clause
    Copyright(c) 2010-2014 Intel Corporation.

.. _testpmd_ug:

Testpmd Application User Guide
==============================

.. toctree::
    :maxdepth: 3
    :numbered:

    intro
    build_app
    run_app
    testpmd_funcs
