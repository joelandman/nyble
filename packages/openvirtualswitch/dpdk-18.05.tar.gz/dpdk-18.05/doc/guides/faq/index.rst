..  SPDX-License-Identifier: BSD-3-Clause
    Copyright(c) 2010-2014 Intel Corporation.

FAQ
===

This document contains some Frequently Asked Questions that arise when working with DPDK.

.. toctree::
    :maxdepth: 2
    :numbered:

    faq
