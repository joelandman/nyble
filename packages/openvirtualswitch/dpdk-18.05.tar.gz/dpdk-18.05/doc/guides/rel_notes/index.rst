..  SPDX-License-Identifier: BSD-3-Clause
    Copyright(c) 2010-2014 Intel Corporation.

Release Notes
=============

.. toctree::
    :maxdepth: 1
    :numbered:

    rel_description
    release_18_05
    release_18_02
    release_17_11
    release_17_08
    release_17_05
    release_17_02
    release_16_11
    release_16_07
    release_16_04
    release_2_2
    release_2_1
    release_2_0
    release_1_8
    known_issues
    deprecation
