..  SPDX-License-Identifier: BSD-3-Clause
    Copyright(c) 2010-2014 Intel Corporation.

DPDK documentation
==================

.. toctree::
   :maxdepth: 1

   linux_gsg/index
   freebsd_gsg/index
   sample_app_ug/index
   prog_guide/index
   howto/index
   tools/index
   testpmd_app_ug/index
   nics/index
   bbdevs/index
   cryptodevs/index
   compressdevs/index
   eventdevs/index
   rawdevs/index
   mempool/index
   platform/index
   contributing/index
   rel_notes/index
   faq/index
